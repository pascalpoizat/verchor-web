##################################################
# VerChor Copyright (C) 2013-2014 University of Grenoble Alpes

# This program is free software; you can redistribute it 
# and/or modify it under the terms of the GNU General Public 
# License as published by the Free Software Foundation; either # version 2 of the License, or (at your option) any later 
# version.

# This program is distributed in the hope that it will be 
# useful, but WITHOUT ANY WARRANTY; without even the implied 
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
# PURPOSE. See the GNU General Public License for more 
# details.

# You should have received a copy of the GNU General Public 
# License along with this program; if not, write to the Free 
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, # Boston, MA 02110-1301 USA.

# http://www.gnu.org/copyleft/gpl.html

# Contributors: 
# Matthias Güdemann
# Gwen Salaün
# Lina Ye 

##################################################


if __name__ == '__main__':
    SUFFIX = ".bpmn"
    import subprocess
    import sys
    import os
    if (len(sys.argv)!=2):
        print "wrong number of arguments"
        sys.exit(1)
    else:
        resource = sys.argv[1]
    # check if bpmn
    elements = resource.split(SUFFIX)
    if (len(elements)>=2 and elements[-1]==''):
        filename = resource[:-(len(SUFFIX))]
        basefilename = os.path.basename(filename)
        dirfilename = os.path.dirname(filename)
    else:
        print "wrong resource type"
        sys.exit(1)
    print "... cleaning up files for %s"%filename
    process = subprocess.Popen('rm -f %s.cif %s.lnt %s*.svl %s*.bcg %s*.aut *.o *.log cp_example* svl* %s.cif cpExa*'%(basefilename,basefilename,basefilename,basefilename,basefilename, filename),shell=True)
    process.communicate()
    print "-- files cleaned up"
