##################################################
# VerChor Copyright (C) 2013-2014 University of Grenoble Alpes

# This program is free software; you can redistribute it 
# and/or modify it under the terms of the GNU General Public 
# License as published by the Free Software Foundation; either # version 2 of the License, or (at your option) any later 
# version.

# This program is distributed in the hope that it will be 
# useful, but WITHOUT ANY WARRANTY; without even the implied 
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
# PURPOSE. See the GNU General Public License for more 
# details.

# You should have received a copy of the GNU General Public 
# License along with this program; if not, write to the Free 
# Software Foundation, Inc., 51 Franklin Street, Fifth Floor, # Boston, MA 02110-1301 USA.

# http://www.gnu.org/copyleft/gpl.html

# Contributors: 
# Matthias Güdemann
# Pascal Poizat 
# Gwen Salaün
# Lina Ye 

##################################################


if __name__ == '__main__':
    import sys
    import os
    import subprocess
    import fcntl
    import select
    import choreo_xml_model
    from realizabilityChecking import *
    import pyxb

    # YOU MAY CHANGE THIS
    HOME = "/home/linaye"
    DIRECTORY = HOME+"/WORKSPACE/src/py"
    CADP_BASE= HOME+"/Desktop/cadp"
    CADP_ARCH = "iX86"
    # DO NOT CHANGE BELOW

    CADP_CMD1 = CADP_BASE+"/bin."+CADP_ARCH
    CADP_CMD2 = CADP_BASE+"/com"
    PATH = "%s:%s:%s"%(os.environ["PATH"],CADP_CMD1,CADP_CMD2)
    SUFFIX = ".bpmn"
    SUFFIX2 = ".cif"
    EXEC = "/usr/bin/python"
    SCRIPTS = {}
    
    SCRIPTS["SynchronizabilityRealizability"] = DIRECTORY+"/realizabilityChecking.py"
    SCRIPTS["LTSgeneration"]=DIRECTORY+"/realizabilityChecking.py"
    SCRIPTS["Controlgeneration"]=DIRECTORY+"/controllerGeneration.py"

    # check if argument
    if (len(sys.argv)!=3):
        print "wrong number of arguments"
        sys.exit(1)
    else:
        resource = sys.argv[1]
        action_name = sys.argv[2]
        if action_name not in SCRIPTS.keys():
            print "%s : unknown action" %action_name
            sys.exit(1)
        else:
            action = SCRIPTS[action_name]

    # check if bpmn
    elements = resource.split(SUFFIX)
    if (len(elements)>=2 and elements[-1]==''):
        filename = resource[:-(len(SUFFIX))]
        full_filename = filename+SUFFIX2
    else:
        print "wrong resource type"
        sys.exit(1)

    # begin

    print "current resource is: %s"%resource
    checker = Checker()

    # Generate LTS
    if action_name=="LTSgeneration":
        choreo = Choreography()
        choreo.buildChoreoFromFile(full_filename, True)

        choreo.computeSyncSets(True)
        choreo.genLNT()
        filename=choreo.name
        choreo.genSVL(False, False)

        
        checker.cleanUp(choreo)
        checker.generateLTS(choreo, False)

        print ("generated LTS for", full_filename)
        sys.exit(0)

    # Check synchronizability and realizability of the choreography
    if action_name=="SynchronizabilityRealizability":
        choreo = Choreography()
        choreo.buildChoreoFromFile(full_filename, True)

        checker.cleanResults(choreo)
        result = checker.isSynchronizableP(choreo, False)

        if result:
            print "choreography is synchronizable"
            print "======\n"
        else:
            print "The choreography is not synchronizable"
            print "======\n"

        result = checker.isRealizableP(choreo, False)
        
        if result:
            print "choreography is realizable in this form"
            print "======\n"
            sys.exit(0)
        else:
            print "choreography is not realizable in this form"
            print "======\n"
            sys.exit(1)

    # Check repairability and generate controller
    if action_name=="Controlgeneration":
        process = subprocess.Popen ([EXEC, action, full_filename], env = {'PATH': PATH, 'CADP': CADP_BASE}, shell = False, stderr=subprocess.STDOUT, stdout=sys.stdout)
        process.communicate()
        sys.exit(0)
     
